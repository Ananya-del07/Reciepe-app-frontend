import * as bcrypt from "./types.js";
export = bcrypt;
export as namespace bcrypt;
